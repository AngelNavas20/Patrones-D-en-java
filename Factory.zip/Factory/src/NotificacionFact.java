interface NotificacionFact {
    Notificacion crearEmailNotificacion();
    Notificacion crearSMSNotificacion();
}