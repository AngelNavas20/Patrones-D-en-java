public interface RutaStrategy {
    String calcularRuta(String puntoA, String puntoB);
}
